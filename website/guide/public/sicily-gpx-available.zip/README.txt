Fausto's Sicily courses. Stage 1 supplied 3 October 2026; other exports checked 30 September 2026.
Available stages: 1, 2, 3, 4, 6, 7, 8.
Missing stages: 5.
Stage 2 showed 65.76 km / 1,334 m on Garmin on 30 September, versus 71.36 km / 1,430 m in the earlier plan; confirm with Fausto.
GPX files retain all exported points unchanged. Use offline navigation and check road conditions.
